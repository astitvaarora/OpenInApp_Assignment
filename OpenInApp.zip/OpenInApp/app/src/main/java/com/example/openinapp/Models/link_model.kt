package com.example.openinapp.Models

data class link_model (
    val pic : String,
    val link_name : String,
    val date : String,
    val link : String,
    val no_of_click : String,
    )