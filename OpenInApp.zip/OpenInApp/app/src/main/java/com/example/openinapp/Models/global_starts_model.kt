package com.example.openinapp.Models

data class global_starts_model(
    val icon : Int,
    val data : String,
    val data_title : String
)